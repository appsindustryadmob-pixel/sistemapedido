<?php
ob_start();
require_once 'config.php';

// Verificar inicio de sesi車n
if (!isset($_SESSION['logged_in'])) {
    header('Location: index.php');
    exit;
}

// L車gica para verificar credenciales de administrador
$usuarioEsAdmin = ($_SESSION['name'] === 'admin' || $_SESSION['name'] === 'Nelson');
 // Cambia esto por tu l車gica real

// Asignar el rol del usuario en la sesi車n
$_SESSION['role'] = $usuarioEsAdmin ? '1' : '0';

// Obtener el rol del usuario si est芍 definido
$rolUsuario = isset($_SESSION['role']) ? $_SESSION['role'] : '';


// Obtener la 迆ltima parte de la URL
$uri = basename($_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="muni">
    <title>Suministros Selectos</title>
    <link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</head>

<body>

    <!-- Static navbar -->
    <div role="navigation" class="navbar navbar-inverse navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" data-toggle="collapse" data-target=".navbar-collapse" class="navbar-toggle collapsed">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li <?php if ($uri == 'home.php') echo "class='active'"; ?>><a href="home.php">Inicio</a></li>
                    <li <?php if ($uri == 'info.php') echo "class='active'"; ?>><a href="info.php">Info Pedidos</a></li>
                    <?php if ($_SESSION['role'] !== '0') { ?>
    <li <?php if ($uri == 'admin.php' || $uri == 'agregar_pro.php') echo "class='active'"; ?> class="dropdown">
        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Panel de Admin <span class="caret"></span></a>
        <ul role="menu" class="dropdown-menu">
            <li <?php if ($uri == 'admin.php') echo "class='active'"; ?>><a href="admin.php">Usuarios</a></li>
            <li <?php if ($uri == 'agregar_pro.php') echo "class='active'"; ?>><a href="agregar_pro.php">Agregar Producto</a></li>
            <li <?php if ($uri == 'inventario.php') echo "class='active'"; ?>><a href="inventario.php">Inventario</a></li>
            <li <?php if ($uri == 'ver_inventario.php') echo "class='active'"; ?>><a href="ver_inventario.php">Ver Inventario</a></li>
            <li <?php if ($uri == 'ver_resumen.php') echo "class='active'"; ?>><a href="ver_resumen.php">Ver Resumen Compras</a></li>
            <li <?php if ($uri == 'registros_gastos.php') echo "class='active'"; ?>><a href="registros_gastos.php">Compras</a></li>
            <!-- Puedes agregar más opciones de menú para admin aquí -->
        </ul>
    </li>
<?php } ?>


                    
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">
                            Hola,
                            <?php if ($_SESSION['logged_in']) { ?>
                                <?php echo htmlspecialchars($_SESSION['name']); ?>
                                <span class="caret"></span>
                        </a>
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="account.php">Mi cuenta</a></li>
                            <li class="divider"></li>
                            <li><a href="logout.php">Salir</a></li>
                        </ul>
                        <?php } ?>
                    </li>
                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </div>
</body>

</html>

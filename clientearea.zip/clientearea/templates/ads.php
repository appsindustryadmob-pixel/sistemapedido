<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banner de Publicidad</title>
    <style>
        /* Estilos para hacer la imagen responsive y bordes redondeados */
        .ad-container {
            text-align: center; /* Centrar el contenido */
        }

        .ad-image {
            width: 100%;
            height: auto;
            border-radius: 10px; /* Ajusta el valor para cambiar la cantidad de redondeo */
        }

        .ad-text {
            margin-top: 10px; /* Espacio entre la imagen y el texto, ajusta según tus preferencias */
        }

        /* Estilos opcionales para ocultar el banner en dispositivos no móviles */
        @media (min-width: 768px) {
            .mobile-only {
                display: none;
            }
        }

        /* Agregar margen desde arriba */
        .mobile-only {
            margin-top: 20px; /* Puedes ajustar la cantidad de margen según tus preferencias */
        }
    </style>
</head>
<body>

    <!-- Banner de Publicidad (Visible solo en dispositivos móviles) -->
    <div class="mobile-only ad-container">
        <a href="https://localconnect.online/" target="_blank">
            <img src="img/banerlocalconnect.png" alt="Publicidad" class="ad-image">
            <p class="ad-text">¡Visita nuestro sitio para obtener ofertas increíbles!</p>
        </a>
    </div>

</body>
<script>
    if (/Mobi/.test(navigator.userAgent)) {
        // El usuario está en un dispositivo móvil, mostrar el banner
        document.querySelector('.mobile-only').style.display = 'block';
    }
</script>
</html>
